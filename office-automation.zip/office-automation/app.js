// ==========================================
// اتوماسیون اداری ابری - Main Application
// ==========================================

// ---- Data Store (localStorage) ----
const DB = {
    get(key) { 
        try { return JSON.parse(localStorage.getItem('oa_' + key)); } 
        catch(e) { return null; }
    },
    set(key, val) { localStorage.setItem('oa_' + key, JSON.stringify(val)); },
    remove(key) { localStorage.removeItem('oa_' + key); }
};

// ---- Default Data ----
const defaultLetters = [
    { id: 'L001', number: '۱۴۰۴/۱/۱۰۱', type: 'incoming', subject: 'درخواست همکاری', from: 'شرکت الف', to: 'مدیریت', date: '۱۴۰۴/۰۶/۲۰', status: 'approved', body: 'با سلام و احترام، خواهشمند است دستور فرمایید نسبت به همکاری در پروژه...', cc: ['حسابداری', 'منابع انسانی'], ref: ['مدیر عامل'] },
    { id: 'L002', number: '۱۴۰۴/۱/۱۰۲', type: 'outgoing', subject: 'پاسخ درخواست همکاری', from: 'مدیریت', to: 'شرکت الف', date: '۱۴۰۴/۰۶/۲۱', status: 'sent', body: 'پاسخ درخواست همکاری شما مثبت است...', cc: [], ref: [] },
    { id: 'L003', number: '۱۴۰۴/۱/۱۰۳', type: 'internal', subject: 'اطلاعیه جلسه', from: 'دبیرخانه', to: 'همه واحدها', date: '۱۴۰۴/۰۶/۲۲', status: 'sent', body: 'جلسه هماهنگی روز دوشنبه...', cc: ['مدیریت'], ref: [] },
    { id: 'L004', number: '۱۴۰۴/۱/۱۰۴', type: 'incoming', subject: 'ارسال فاکتور', from: 'شرکت ب', to: 'حسابداری', date: '۱۴۰۴/۰۶/۲۳', status: 'pending', body: 'فاکتور شماره ۱۲۳۴ پیوست می‌باشد...', cc: ['مدیر مالی'], ref: ['مدیر عامل'] },
    { id: 'L005', number: '۱۴۰۴/۱/۱۰۵', type: 'outgoing', subject: 'دعوت‌نامه همایش', from: 'روابط عمومی', to: 'شرکت‌های همکار', date: '۱۴۰۴/۰۶/۲۴', status: 'draft', body: 'بدین‌وسیله از جنابعالی دعوت می‌گردد...', cc: [], ref: [] },
];

const defaultUsers = [
    { id: 'U001', name: 'محمد احمدی', phone: '09121234567', title: 'مدیر سیستم', access: 'admin', email: 'mohammadi@company.ir', status: 'active', online: true },
    { id: 'U002', name: 'زهرا محمدی', phone: '09131234567', title: 'رئیس دبیرخانه', access: 'editor', email: 'mohammadi.z@company.ir', status: 'active', online: true },
    { id: 'U003', name: 'علی رضایی', phone: '09141234567', title: 'کارشناس اداری', access: 'editor', email: 'rezaei@company.ir', status: 'active', online: false },
    { id: 'U004', name: 'مریم کریمی', phone: '09151234567', title: 'مسئول بایگانی', access: 'viewer', email: 'karimi@company.ir', status: 'active', online: true },
    { id: 'U005', name: 'حسین نوری', phone: '09161234567', title: 'حسابرس', access: 'limited', email: 'nouri@company.ir', status: 'active', online: false, limitedAccess: ['secretariat', 'reports'] },
    { id: 'U006', name: 'سارا حسینی', phone: '09171234567', title: 'کارشناس مالی', access: 'limited', email: 'hosseini@company.ir', status: 'active', online: true, limitedAccess: ['secretariat', 'archive'] },
];

const defaultChatMessages = [
    { from: 'U001', to: 'U002', text: 'سلام، نامه شماره ۱۰۳ رو بررسی کنید لطفاً', time: '۰۹:۳۰' },
    { from: 'U002', to: 'U001', text: 'بله حتماً، الان بررسی می‌کنم', time: '۰۹:۳۲' },
    { from: 'U001', to: 'U004', text: 'اسناد ماه گذشته رو بایگانی کردید؟', time: '۱۰:۱۵' },
    { from: 'U004', to: 'U001', text: 'بله، همه اسناد بایگانی شد', time: '۱۰:۲۰' },
    { from: 'U001', to: 'U003', text: 'جلسه فردا ساعت ۱۰ صبح برگزار می‌شه', time: '۱۴:۰۰' },
];

const defaultArchiveItems = [
    { id: 'A001', title: 'قرارداد همکاری ۱۴۰۴', category: 'contracts', date: '۱۴۰۴/۰۱/۱۵', desc: 'قرارداد همکاری با شرکت الف' },
    { id: 'A002', title: 'نامه ورودی شماره ۵۰', category: 'incoming', date: '۱۴۰۴/۰۳/۱۰', desc: 'نامه رسمی از سازمان بازرسی' },
    { id: 'A003', title: 'گزارش مالی Q1', category: 'reports', date: '۱۴۰۴/۰۴/۰۱', desc: 'گزارش مالی سه‌ماهه اول' },
];

const defaultFolders = [
    { id: 'F001', name: 'پروژه الف', color: '#1a237e', count: 5 },
    { id: 'F002', name: 'قراردادها', color: '#ff6f00', count: 12 },
    { id: 'F003', name: 'مکاتبات داخلی', color: '#2e7d32', count: 8 },
    { id: 'F004', name: 'بایگانی سال ۱۴۰۳', color: '#7b1fa2', count: 45 },
];

const defaultNotifications = [
    { id: 'N001', text: 'نامه جدید از شرکت الف دریافت شد', time: '۲ دقیقه پیش', icon: 'fa-envelope', read: false },
    { id: 'N002', text: 'نامه شماره ۱۰۴ تأیید شد', time: '۱۵ دقیقه پیش', icon: 'fa-check', read: false },
    { id: 'N003', text: 'زهرا محمدی آنلاین شد', time: '۳۰ دقیقه پیش', icon: 'fa-user', read: false },
];

const defaultBackups = [
    { id: 'B001', date: '۱۴۰۴/۰۶/۲۵', time: '۱۴:۳۰', size: '0.8', type: 'خودکار' },
    { id: 'B002', date: '۱۴۰۴/۰۶/۲۰', time: '۱۰:۰۰', size: '0.7', type: 'دستی' },
    { id: 'B003', date: '۱۴۰۴/۰۶/۱۵', time: '۰۹:۰۰', size: '0.9', type: 'خودکار' },
];

// ---- Init Data ----
function initData() {
    if (!DB.get('letters')) DB.set('letters', defaultLetters);
    if (!DB.get('users')) DB.set('users', defaultUsers);
    if (!DB.get('chats')) DB.set('chats', defaultChatMessages);
    if (!DB.get('archive')) DB.set('archive', defaultArchiveItems);
    if (!DB.get('folders')) DB.set('folders', defaultFolders);
    if (!DB.get('notifications')) DB.set('notifications', defaultNotifications);
    if (!DB.get('backups')) DB.set('backups', defaultBackups);
    if (!DB.get('settings')) DB.set('settings', {
        company: { name: 'شرکت نمونه', sub: 'شرکت سهامی خاص - شماره ثبت: ۱۲۳۴۵', address: 'تهران، خیابان ولیعصر، پلاک ۱۰۰', phone: '۰۲۱-۱۲۳۴۵۶۷۸' },
        theme: { primary: '#1a237e', mode: 'light' },
        font: { family: "'Vazirmatn', sans-serif", size: 14 },
        icons: 'solid'
    });
}

// ---- App State ----
let currentUser = null;
let currentPage = 'dashboard';
let countdownTimer = null;
let sidebarOpen = true;
let sigDrawing = false;
let sigCtx = null;

// ---- Initialize ----
window.addEventListener('DOMContentLoaded', () => {
    initData();
    
    // Check login
    const savedUser = DB.get('currentUser');
    if (savedUser) {
        currentUser = savedUser;
        showApp();
    }
    
    // Online/Offline detection
    window.addEventListener('online', () => {
        document.getElementById('offlineBanner').classList.remove('show');
        showToast('ارتباط اینترنتی برقرار شد', 'success');
    });
    window.addEventListener('offline', () => {
        document.getElementById('offlineBanner').classList.add('show');
    });
    if (!navigator.onLine) {
        document.getElementById('offlineBanner').classList.add('show');
    }
    
    // Register Service Worker
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
    
    // Signature Canvas
    initSignatureCanvas();
    
    // Auto-generate letter number
    updateLetterNumber();
    
    // Set today date
    document.getElementById('letterDate').value = getTodayJalali();
});

// ---- Persian Date Helper ----
function getTodayJalali() {
    const now = new Date();
    const j = gregorianToJalali(now.getFullYear(), now.getMonth()+1, now.getDate());
    return `${j[0]}/${pad(j[1])}/${pad(j[2])}`;
}

function pad(n) { return n < 10 ? '0' + n : '' + n; }

function gregorianToJalali(gy, gm, gd) {
    const gdm = [0,31,59,90,120,151,181,212,243,273,304,334];
    const gy2 = (gm > 2) ? (gy + 1) : gy;
    const days = 355666 + (365 * gy) + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) + gd + gdm[gm - 1];
    const jy = -1595 + (33 * Math.floor(days / 12053));
    const jd2 = days % 12053;
    jy += 4 * Math.floor(jd2 / 1461);
    const jd3 = jd2 % 1461;
    if (jd3 > 365) {
        jy += Math.floor((jd3 - 1) / 365);
        jd3 = (jd3 - 1) % 365;
    }
    let jm, dd;
    if (jd3 < 186) {
        jm = 1 + Math.floor(jd3 / 31);
        dd = 1 + (jd3 % 31);
    } else {
        jm = 7 + Math.floor((jd3 - 186) / 30);
        dd = 1 + ((jd3 - 186) % 30);
    }
    return [jy, jm, dd];
}

// ---- Auth ----
function switchAuthTab(tab) {
    document.querySelectorAll('.tab-switch button').forEach(b => b.classList.remove('active'));
    event.target.classList.add('active');
    document.getElementById('loginForm').style.display = tab === 'login' ? 'block' : 'none';
    document.getElementById('registerForm').style.display = tab === 'register' ? 'block' : 'none';
}

function sendOTP(type) {
    const phone = type === 'login' 
        ? document.getElementById('loginPhone').value 
        : document.getElementById('regPhone').value;
    
    if (!phone || !/^09[0-9]{9}$/.test(phone)) {
        showToast('شماره موبایل معتبر وارد کنید (مثال: 09121234567)', 'error');
        return;
    }
    
    if (type === 'register') {
        const name = document.getElementById('regName').value;
        if (!name) {
            showToast('نام و نام خانوادگی الزامی است', 'error');
            return;
        }
    }
    
    // Show OTP section
    const section = type === 'login' ? 'loginOtpSection' : 'registerOtpSection';
    document.getElementById(section).style.display = 'block';
    
    // Start countdown
    startCountdown(type);
    
    // Simulate OTP (in real app, send via SMS API)
    showToast(`کد تأیید به شماره ${phone} ارسال شد (کد نمونه: ۱۲۳۴۵)`, 'success');
}

function startCountdown(type) {
    let seconds = 120;
    const spanId = type === 'login' ? 'loginCountdown' : 'registerCountdown';
    
    if (countdownTimer) clearInterval(countdownTimer);
    
    countdownTimer = setInterval(() => {
        seconds--;
        document.getElementById(spanId).textContent = seconds;
        if (seconds <= 0) {
            clearInterval(countdownTimer);
            document.getElementById(spanId).parentElement.innerHTML = 
                '<button class="btn btn-sm btn-outline" onclick="sendOTP(\'' + type + '\')" style="width:auto;">ارسال مجدد کد</button>';
        }
    }, 1000);
}

function otpNext(input) {
    if (input.value.length === 1) {
        const next = input.nextElementSibling;
        if (next) next.focus();
    }
}

function verifyOTP(type) {
    const section = type === 'login' ? 'loginOtpSection' : 'registerOtpSection';
    const inputs = document.getElementById(section).querySelectorAll('.otp-input');
    let code = '';
    inputs.forEach(i => code += i.value);
    
    if (code.length < 5) {
        showToast('کد تأیید ۵ رقمی را کامل وارد کنید', 'error');
        return;
    }
    
    if (type === 'login') {
        const phone = document.getElementById('loginPhone').value;
        const users = DB.get('users') || [];
        const user = users.find(u => u.phone === phone);
        
        if (user) {
            currentUser = user;
            DB.set('currentUser', user);
            showApp();
            showToast(`خوش آمدید، ${user.name}`, 'success');
        } else {
            showToast('شماره موبایل ثبت‌نام نشده. ابتدا ثبت‌نام کنید.', 'error');
        }
    } else {
        const phone = document.getElementById('regPhone').value;
        const name = document.getElementById('regName').value;
        const title = document.getElementById('regTitle').value || 'کاربر';
        const email = document.getElementById('regEmail').value || '';
        
        const users = DB.get('users') || [];
        const newUser = {
            id: 'U' + Date.now(),
            name, phone, title,
            access: 'viewer',
            email,
            status: 'active',
            online: true
        };
        users.push(newUser);
        DB.set('users', users);
        
        currentUser = newUser;
        DB.set('currentUser', newUser);
        showApp();
        showToast(`ثبت‌نام موفق. خوش آمدید، ${name}`, 'success');
    }
}

function showApp() {
    document.getElementById('loginPage').style.display = 'none';
    document.getElementById('appContainer').style.display = 'block';
    
    // Update sidebar user info
    document.getElementById('sidebarUserName').textContent = currentUser.name;
    document.getElementById('sidebarAvatar').textContent = currentUser.name.charAt(0);
    
    loadDashboard();
    loadLetters();
    loadUsers();
    loadArchive();
    loadFolders();
    loadChat();
    loadBackups();
    applySettings();
}

function logout() {
    DB.remove('currentUser');
    currentUser = null;
    document.getElementById('loginPage').style.display = 'flex';
    document.getElementById('appContainer').style.display = 'none';
    if (countdownTimer) clearInterval(countdownTimer);
    showToast('با موفقیت خارج شدید', 'info');
}

// ---- Navigation ----
function navigateTo(page) {
    currentPage = page;
    
    // Update sidebar
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.toggle('active', item.dataset.page === page);
    });
    
    // Update sections
    document.querySelectorAll('.page-section').forEach(s => s.classList.remove('active'));
    const section = document.getElementById('page-' + page);
    if (section) section.classList.add('active');
    
    // Page titles
    const titles = {
        dashboard: 'داشبورد',
        secretariat: 'دبیرخانه - مدیریت نامه‌ها',
        newletter: 'تهیه و تنظیم نامه',
        tracking: 'پیگیری نامه‌ها',
        archive: 'بایگانی اسناد',
        documents: 'مدیریت پرونده‌ها',
        admin: 'مدیریت سیستم',
        users: 'کاربران و سطوح دسترسی',
        chat: 'گفتگوی آنلاین',
        reports: 'گزارش‌گیری',
        backup: 'پشتیبان‌گیری',
        settings: 'تنظیمات ظاهری'
    };
    document.getElementById('pageTitle').textContent = titles[page] || page;
    
    // Close mobile sidebar
    if (window.innerWidth <= 768) {
        document.getElementById('sidebar').classList.remove('mobile-show');
        document.getElementById('sidebarOverlay').classList.remove('show');
    }
    
    // Load page data
    if (page === 'dashboard') loadDashboard();
    if (page === 'secretariat') loadLetters();
    if (page === 'tracking') loadTracking();
    if (page === 'chat') loadChat();
    if (page === 'users') loadUsers();
    if (page === 'archive') loadArchive();
    if (page === 'documents') loadFolders();
    if (page === 'backup') loadBackups();
    if (page === 'reports') { /* reports page loaded on demand */ }
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    if (window.innerWidth <= 768) {
        sidebar.classList.toggle('mobile-show');
        overlay.classList.toggle('show');
    } else {
        sidebarOpen = !sidebarOpen;
        sidebar.classList.toggle('collapsed', !sidebarOpen);
        document.getElementById('header').classList.toggle('sidebar-collapsed', !sidebarOpen);
        document.getElementById('mainContent').classList.toggle('full', !sidebarOpen);
    }
}

// ---- Dashboard ----
function loadDashboard() {
    const letters = DB.get('letters') || [];
    const incoming = letters.filter(l => l.type === 'incoming').length;
    const outgoing = letters.filter(l => l.type === 'outgoing').length;
    const approved = letters.filter(l => l.status === 'approved').length;
    const pending = letters.filter(l => l.status === 'pending' || l.status === 'draft').length;
    
    document.getElementById('statLetters').textContent = toPersianNum(incoming);
    document.getElementById('statSent').textContent = toPersianNum(outgoing);
    document.getElementById('statApproved').textContent = toPersianNum(approved);
    document.getElementById('statPending').textContent = toPersianNum(pending);
    
    // Recent letters
    const tbody = document.getElementById('dashRecentLetters');
    tbody.innerHTML = letters.slice(0, 5).map(l => `
        <tr>
            <td>${l.number}</td>
            <td>${l.subject}</td>
            <td>${l.from}</td>
            <td>${l.date}</td>
            <td><span class="status-badge ${l.status}">${statusText(l.status)}</span></td>
        </tr>
    `).join('');
    
    // Notifications
    const notifs = DB.get('notifications') || [];
    document.getElementById('dashNotifications').innerHTML = notifs.map(n => `
        <div style="display:flex; align-items:center; gap:12px; padding:10px; border-bottom:1px solid var(--border); ${!n.read ? 'background:rgba(26,35,126,0.03);' : ''}">
            <i class="fas ${n.icon}" style="color:var(--primary); width:20px;"></i>
            <span style="flex:1; font-size:13px;">${n.text}</span>
            <small style="color:var(--text-light); font-size:11px;">${n.time}</small>
        </div>
    `).join('');
}

// ---- Letters ----
function loadLetters() {
    const letters = DB.get('letters') || [];
    const tbody = document.getElementById('lettersTableBody');
    tbody.innerHTML = letters.map(l => {
        const typeText = l.type === 'incoming' ? 'وارده' : l.type === 'outgoing' ? 'صادره' : 'داخلی';
        return `
        <tr>
            <td>${l.number}</td>
            <td>${l.subject}</td>
            <td><span class="chip"><i class="fas ${l.type === 'incoming' ? 'fa-inbox' : l.type === 'outgoing' ? 'fa-paper-plane' : 'fa-building'}"></i> ${typeText}</span></td>
            <td>${l.type === 'incoming' ? l.from : l.to}</td>
            <td>${l.date}</td>
            <td><span class="status-badge ${l.status}">${statusText(l.status)}</span></td>
            <td>
                <button class="btn btn-sm btn-outline" onclick="viewLetter('${l.id}')" style="width:auto; padding:4px 8px;"><i class="fas fa-eye"></i></button>
                <button class="btn btn-sm btn-outline" onclick="archiveLetter('${l.id}')" style="width:auto; padding:4px 8px;"><i class="fas fa-archive"></i></button>
            </td>
        </tr>`;
    }).join('');
    
    document.getElementById('lettersBadge').textContent = toPersianNum(letters.filter(l => l.status === 'pending').length);
}

function filterLetters() {
    const search = document.getElementById('searchLetters').value.toLowerCase();
    const type = document.getElementById('filterLetterType').value;
    const status = document.getElementById('filterLetterStatus').value;
    const letters = DB.get('letters') || [];
    
    const filtered = letters.filter(l => {
        const matchSearch = !search || l.number.includes(search) || l.subject.includes(search) || l.from.includes(search) || l.to.includes(search);
        const matchType = type === 'all' || l.type === type;
        const matchStatus = status === 'all' || l.status === status;
        return matchSearch && matchType && matchStatus;
    });
    
    const tbody = document.getElementById('lettersTableBody');
    tbody.innerHTML = filtered.map(l => {
        const typeText = l.type === 'incoming' ? 'وارده' : l.type === 'outgoing' ? 'صادره' : 'داخلی';
        return `
        <tr>
            <td>${l.number}</td>
            <td>${l.subject}</td>
            <td><span class="chip"><i class="fas ${l.type === 'incoming' ? 'fa-inbox' : l.type === 'outgoing' ? 'fa-paper-plane' : 'fa-building'}"></i> ${typeText}</span></td>
            <td>${l.type === 'incoming' ? l.from : l.to}</td>
            <td>${l.date}</td>
            <td><span class="status-badge ${l.status}">${statusText(l.status)}</span></td>
            <td>
                <button class="btn btn-sm btn-outline" onclick="viewLetter('${l.id}')" style="width:auto; padding:4px 8px;"><i class="fas fa-eye"></i></button>
                <button class="btn btn-sm btn-outline" onclick="archiveLetter('${l.id}')" style="width:auto; padding:4px 8px;"><i class="fas fa-archive"></i></button>
            </td>
        </tr>`;
    }).join('');
}

function updateLetterNumber() {
    const letters = DB.get('letters') || [];
    const today = getTodayJalali();
    const count = letters.filter(l => l.date === today).length + 1;
    const parts = today.split('/');
    const num = `${parts[0]}/${parts[1]}/${toPersianNum(count)}`;
    document.getElementById('letterNumber').value = num;
}

function addCC() {
    const input = document.getElementById('ccInput');
    const val = input.value.trim();
    if (!val) return;
    
    const list = document.getElementById('ccList');
    const chip = document.createElement('span');
    chip.className = 'chip';
    chip.innerHTML = `${val} <i class="fas fa-times" style="cursor:pointer; margin-right:4px;" onclick="this.parentElement.remove()"></i>`;
    list.appendChild(chip);
    input.value = '';
}

function addRef() {
    const input = document.getElementById('refInput');
    const val = input.value.trim();
    if (!val) return;
    
    const list = document.getElementById('refList');
    const chip = document.createElement('span');
    chip.className = 'chip';
    chip.innerHTML = `${val} <i class="fas fa-times" style="cursor:pointer; margin-right:4px;" onclick="this.parentElement.remove()"></i>`;
    list.appendChild(chip);
    input.value = '';
}

function saveLetter(status) {
    const letters = DB.get('letters') || [];
    const newLetter = {
        id: 'L' + Date.now(),
        number: document.getElementById('letterNumber').value,
        type: document.getElementById('letterType').value,
        subject: document.getElementById('letterSubject').value,
        from: document.getElementById('letterFrom').value,
        to: document.getElementById('letterTo').value,
        date: document.getElementById('letterDate').value,
        body: document.getElementById('letterBody').value,
        cc: getChipsText('ccList'),
        ref: getChipsText('refList'),
        status,
        sigName: document.getElementById('sigName').value,
        sigTitle: document.getElementById('sigTitle').value,
        stamp: document.getElementById('stampOnLetter').checked,
        paperSize: document.getElementById('paperSize').value,
        company: document.getElementById('companyName').value
    };
    
    if (!newLetter.subject || !newLetter.body) {
        showToast('موضوع و متن نامه الزامی است', 'error');
        return;
    }
    
    letters.push(newLetter);
    DB.set('letters', letters);
    
    updateLetterNumber();
    showToast(status === 'draft' ? 'نامه به عنوان پیش‌نویس ذخیره شد' : 'نامه ذخیره و ارسال شد', 'success');
    navigateTo('secretariat');
}

function getChipsText(containerId) {
    const chips = document.getElementById(containerId).querySelectorAll('.chip');
    return Array.from(chips).map(c => c.textContent.replace('×', '').trim()).filter(t => t);
}

function viewLetter(id) {
    const letters = DB.get('letters') || [];
    const letter = letters.find(l => l.id === id);
    if (!letter) return;
    
    const settings = DB.get('settings');
    const company = settings ? settings.company : { name: 'شرکت نمونه', sub: '', address: '', phone: '' };
    
    const content = document.getElementById('letterPreviewContent');
    content.innerHTML = `
        <div class="letter-header-preview">
            <div class="company-name">${letter.company || company.name}</div>
            <div class="company-sub">${company.sub}</div>
            ${company.address ? '<div style="font-size:10px; margin-top:4px;">' + company.address + ' | تلفن: ' + company.phone + '</div>' : ''}
        </div>
        <div class="letter-number-row">
            <span>شماره: ${letter.number}</span>
            <span>تاریخ: ${letter.date}</span>
            <span>پیوست: ${letter.attachment ? 'دارد' : 'ندارد'}</span>
        </div>
        <div style="margin-bottom:12px;"><strong>موضوع:</strong> ${letter.subject}</div>
        <div style="margin-bottom:8px;"><strong>فرستنده:</strong> ${letter.from} &nbsp;&nbsp; <strong>گیرنده:</strong> ${letter.to}</div>
        ${letter.cc && letter.cc.length ? '<div style="margin-bottom:8px;"><strong>رونوشت:</strong> ' + letter.cc.join('، ') + '</div>' : ''}
        ${letter.ref && letter.ref.length ? '<div style="margin-bottom:8px;"><strong>ارجاع:</strong> ' + letter.ref.join('، ') + '</div>' : ''}
        <hr style="margin:16px 0; border:0; border-top:1px solid #ddd;">
        <div style="line-height:2; text-align:justify;">${letter.body}</div>
        <div class="signature-area">
            <div class="signature-block">
                ${letter.sigName ? '<div class="sig-name">' + letter.sigName + '</div>' : ''}
                ${letter.sigTitle ? '<div class="sig-title">' + letter.sigTitle + '</div>' : ''}
            </div>
            ${letter.stamp ? '<div class="stamp-preview"><span>' + (letter.company || company.name) + '</span><span style="font-size:9px; margin-top:4px;">تأیید شد</span></div>' : ''}
        </div>
    `;
    
    openModal('letterPreviewModal');
}

function previewLetter() {
    const settings = DB.get('settings');
    const company = settings ? settings.company : { name: 'شرکت نمونه', sub: '', address: '', phone: '' };
    
    const content = document.getElementById('letterPreviewContent');
    const cName = document.getElementById('companyName').value || company.name;
    content.innerHTML = `
        <div class="letter-header-preview">
            <div class="company-name">${cName}</div>
            <div class="company-sub">${company.sub}</div>
            ${company.address ? '<div style="font-size:10px; margin-top:4px;">' + company.address + ' | تلفن: ' + company.phone + '</div>' : ''}
        </div>
        <div class="letter-number-row">
            <span>شماره: ${document.getElementById('letterNumber').value}</span>
            <span>تاریخ: ${document.getElementById('letterDate').value}</span>
            <span>سایز: ${document.getElementById('paperSize').value}</span>
        </div>
        <div style="margin-bottom:12px;"><strong>موضوع:</strong> ${document.getElementById('letterSubject').value || '-'}</div>
        <div style="margin-bottom:8px;"><strong>فرستنده:</strong> ${document.getElementById('letterFrom').value || '-'} &nbsp;&nbsp; <strong>گیرنده:</strong> ${document.getElementById('letterTo').value || '-'}</div>
        <div id="previewCC"></div>
        <div id="previewRef"></div>
        <hr style="margin:16px 0; border:0; border-top:1px solid #ddd;">
        <div style="line-height:2; text-align:justify;">${document.getElementById('letterBody').value || '-'}</div>
        <div class="signature-area">
            <div class="signature-block">
                <div class="sig-line"></div>
                <div class="sig-name">${document.getElementById('sigName').value || ''}</div>
                <div class="sig-title">${document.getElementById('sigTitle').value || ''}</div>
            </div>
            ${document.getElementById('stampOnLetter').checked ? '<div class="stamp-preview"><span>' + cName + '</span><span style="font-size:9px; margin-top:4px;">تأیید شد</span></div>' : ''}
        </div>
    `;
    
    // Show CC and Ref
    const ccText = getChipsText('ccList');
    const refText = getChipsText('refList');
    if (ccText.length) document.getElementById('previewCC').innerHTML = '<div style="margin-bottom:8px;"><strong>رونوشت:</strong> ' + ccText.join('، ') + '</div>';
    if (refText.length) document.getElementById('previewRef').innerHTML = '<div style="margin-bottom:8px;"><strong>ارجاع:</strong> ' + refText.join('، ') + '</div>';
    
    openModal('letterPreviewModal');
}

function printLetter() {
    const content = document.getElementById('letterPreviewContent').innerHTML;
    const win = window.open('', '_blank');
    win.document.write(`
        <html dir="rtl" lang="fa">
        <head>
            <title>چاپ نامه</title>
            <style>
                body { font-family: 'Vazirmatn', Tahoma, sans-serif; direction: rtl; padding: 20px; }
                .company-name { font-size: 20px; font-weight: 800; text-align: center; color: #1a237e; }
                .company-sub { font-size: 12px; text-align: center; color: #666; margin-top: 4px; }
                .stamp-preview { width: 100px; height: 100px; border: 3px solid #c62828; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-direction: column; color: #c62828; font-weight: 700; font-size: 10px; text-align: center; transform: rotate(-15deg); margin: 10px auto; }
                .signature-block { text-align: center; }
                .sig-line { width: 150px; border-bottom: 1px solid #333; margin-bottom: 6px; min-height: 40px; }
                .sig-name { font-size: 12px; font-weight: 600; }
                .sig-title { font-size: 11px; color: #666; }
                .signature-area { display: flex; justify-content: space-between; margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; }
                .letter-number-row { display: flex; justify-content: space-between; font-size: 12px; color: #666; margin-bottom: 16px; padding: 8px 0; border-bottom: 1px solid #ddd; }
            </style>
        </head>
        <body>${content}</body>
        </html>
    `);
    win.document.close();
    setTimeout(() => win.print(), 500);
}

function archiveLetter(id) {
    const letters = DB.get('letters') || [];
    const letter = letters.find(l => l.id === id);
    if (letter) {
        letter.status = 'archived';
        DB.set('letters', letters);
        
        // Add to archive
        const archive = DB.get('archive') || [];
        archive.push({
            id: 'A' + Date.now(),
            title: letter.subject,
            category: letter.type,
            date: getTodayJalali(),
            desc: letter.number
        });
        DB.set('archive', archive);
        
        loadLetters();
        showToast('نامه به بایگانی منتقل شد', 'success');
    }
}

// ---- Tracking ----
function loadTracking() {
    const letters = DB.get('letters') || [];
    const container = document.getElementById('trackingList');
    
    container.innerHTML = letters.map(l => `
        <div style="display:flex; align-items:flex-start; gap:16px; padding:16px; border-bottom:1px solid var(--border);">
            <div style="width:40px; height:40px; border-radius:10px; background:${l.status === 'approved' ? 'rgba(46,125,50,0.1)' : l.status === 'pending' ? 'rgba(255,111,0,0.1)' : 'rgba(26,35,126,0.1)'}; display:flex; align-items:center; justify-content:center;">
                <i class="fas ${l.status === 'approved' ? 'fa-check' : l.status === 'pending' ? 'fa-clock' : 'fa-envelope'}" style="color:${l.status === 'approved' ? 'var(--success)' : l.status === 'pending' ? 'var(--accent)' : 'var(--primary)'}"></i>
            </div>
            <div style="flex:1;">
                <div style="font-weight:600; font-size:14px;">${l.subject}</div>
                <div style="font-size:12px; color:var(--text-light); margin-top:4px;">شماره: ${l.number} | تاریخ: ${l.date}</div>
                <div style="margin-top:8px;">
                    <span class="status-badge ${l.status}">${statusText(l.status)}</span>
                    ${l.cc && l.cc.length ? '<span style="font-size:11px; color:var(--text-light); margin-right:8px;">رونوشت: ' + l.cc.join('، ') + '</span>' : ''}
                    ${l.ref && l.ref.length ? '<span style="font-size:11px; color:var(--text-light); margin-right:8px;">ارجاع: ' + l.ref.join('، ') + '</span>' : ''}
                </div>
            </div>
            <button class="btn btn-sm btn-outline" onclick="viewLetter('${l.id}')" style="width:auto;"><i class="fas fa-eye"></i></button>
        </div>
    `).join('');
}

function searchTracking() {
    const query = document.getElementById('trackSearch').value.toLowerCase();
    const letters = DB.get('letters') || [];
    const filtered = letters.filter(l => 
        !query || l.number.includes(query) || l.subject.includes(query) || l.from.includes(query)
    );
    
    const container = document.getElementById('trackingList');
    container.innerHTML = filtered.map(l => `
        <div style="display:flex; align-items:flex-start; gap:16px; padding:16px; border-bottom:1px solid var(--border);">
            <div style="width:40px; height:40px; border-radius:10px; background:${l.status === 'approved' ? 'rgba(46,125,50,0.1)' : l.status === 'pending' ? 'rgba(255,111,0,0.1)' : 'rgba(26,35,126,0.1)'}; display:flex; align-items:center; justify-content:center;">
                <i class="fas ${l.status === 'approved' ? 'fa-check' : l.status === 'pending' ? 'fa-clock' : 'fa-envelope'}" style="color:${l.status === 'approved' ? 'var(--success)' : l.status === 'pending' ? 'var(--accent)' : 'var(--primary)'}"></i>
            </div>
            <div style="flex:1;">
                <div style="font-weight:600; font-size:14px;">${l.subject}</div>
                <div style="font-size:12px; color:var(--text-light); margin-top:4px;">شماره: ${l.number} | تاریخ: ${l.date}</div>
                <div style="margin-top:8px;"><span class="status-badge ${l.status}">${statusText(l.status)}</span></div>
            </div>
        </div>
    `).join('');
}

// ---- Archive ----
function loadArchive() {
    const archive = DB.get('archive') || [];
    const tbody = document.getElementById('archiveTableBody');
    tbody.innerHTML = archive.map(a => {
        const catText = { incoming: 'وارده', outgoing: 'صادره', internal: 'داخلی', contracts: 'قرارداد', reports: 'گزارش' }[a.category] || a.category;
        return `
        <tr>
            <td>${a.id}</td>
            <td>${a.title}</td>
            <td><span class="chip">${catText}</span></td>
            <td>${a.date}</td>
            <td>
                <button class="btn btn-sm btn-outline" onclick="removeArchive('${a.id}')" style="width:auto; padding:4px 8px;"><i class="fas fa-trash" style="color:var(--error);"></i></button>
            </td>
        </tr>`;
    }).join('');
}

function searchArchive() {
    const query = document.getElementById('archiveSearch').value.toLowerCase();
    const year = document.getElementById('archiveYear').value;
    const cat = document.getElementById('archiveCategory').value;
    const archive = DB.get('archive') || [];
    
    const filtered = archive.filter(a => {
        const matchSearch = !query || a.title.toLowerCase().includes(query) || (a.desc && a.desc.toLowerCase().includes(query));
        const matchYear = year === 'all' || a.date.includes(year);
        const matchCat = cat === 'all' || a.category === cat;
        return matchSearch && matchYear && matchCat;
    });
    
    const tbody = document.getElementById('archiveTableBody');
    tbody.innerHTML = filtered.map(a => {
        const catText = { incoming: 'وارده', outgoing: 'صادره', internal: 'داخلی', contracts: 'قرارداد', reports: 'گزارش' }[a.category] || a.category;
        return `
        <tr>
            <td>${a.id}</td>
            <td>${a.title}</td>
            <td><span class="chip">${catText}</span></td>
            <td>${a.date}</td>
            <td><button class="btn btn-sm btn-outline" onclick="removeArchive('${a.id}')" style="width:auto; padding:4px 8px;"><i class="fas fa-trash" style="color:var(--error);"></i></button></td>
        </tr>`;
    }).join('');
}

function showAddArchiveModal() { openModal('addArchiveModal'); }

function saveArchiveItem() {
    const archive = DB.get('archive') || [];
    archive.push({
        id: 'A' + Date.now(),
        title: document.getElementById('archiveTitle').value,
        category: document.getElementById('archiveCategorySelect').value,
        date: getTodayJalali(),
        desc: document.getElementById('archiveDesc').value
    });
    DB.set('archive', archive);
    closeModal('addArchiveModal');
    loadArchive();
    showToast('سند به بایگانی اضافه شد', 'success');
}

function removeArchive(id) {
    let archive = DB.get('archive') || [];
    archive = archive.filter(a => a.id !== id);
    DB.set('archive', archive);
    loadArchive();
    showToast('سند از بایگانی حذف شد', 'info');
}

// ---- Folders ----
function loadFolders() {
    const folders = DB.get('folders') || [];
    const grid = document.getElementById('foldersGrid');
    grid.innerHTML = folders.map(f => `
        <div style="display:inline-flex; flex-direction:column; align-items:center; gap:8px; padding:20px; background:white; border-radius:12px; box-shadow:var(--shadow); cursor:pointer; min-width:120px; margin:4px;">
            <i class="fas fa-folder" style="font-size:36px; color:${f.color};"></i>
            <span style="font-size:13px; font-weight:600;">${f.name}</span>
            <span style="font-size:11px; color:var(--text-light);">${toPersianNum(f.count)} سند</span>
        </div>
    `).join('');
}

function showNewFolderModal() { openModal('newFolderModal'); }

function saveNewFolder() {
    const folders = DB.get('folders') || [];
    folders.push({
        id: 'F' + Date.now(),
        name: document.getElementById('folderName').value,
        color: document.getElementById('folderColor').value,
        count: 0
    });
    DB.set('folders', folders);
    closeModal('newFolderModal');
    loadFolders();
    showToast('پرونده جدید ایجاد شد', 'success');
}

// ---- Users ----
function loadUsers() {
    const users = DB.get('users') || [];
    const tbody = document.getElementById('usersTableBody');
    const accessLabels = { admin: 'مدیر سیستم', editor: 'ویرایشگر', viewer: 'مشاهده‌گر', limited: 'محدود' };
    
    tbody.innerHTML = users.map(u => `
        <tr>
            <td>
                <div style="display:flex; align-items:center; gap:8px;">
                    <div style="width:32px; height:32px; border-radius:8px; background:var(--primary); color:white; display:flex; align-items:center; justify-content:center; font-weight:700; font-size:12px;">${u.name.charAt(0)}</div>
                    ${u.name}
                </div>
            </td>
            <td dir="ltr">${u.phone}</td>
            <td>${u.title}</td>
            <td><span class="access-tag ${u.access}">${accessLabels[u.access] || u.access}</span></td>
            <td>
                <span style="display:flex; align-items:center; gap:6px;">
                    ${u.online ? '<span class="online-dot"></span> آنلاین' : '<span style="width:8px;height:8px;background:#999;border-radius:50%;display:inline-block;"></span> آفلاین'}
                </span>
            </td>
            <td>
                <button class="btn btn-sm btn-outline" onclick="editUserAccess('${u.id}')}" style="width:auto; padding:4px 8px;"><i class="fas fa-key"></i></button>
                ${u.id !== currentUser?.id ? '<button class="btn btn-sm btn-outline" onclick="deleteUser(\''+u.id+'\')" style="width:auto; padding:4px 8px;"><i class="fas fa-trash" style="color:var(--error);"></i></button>' : ''}
            </td>
        </tr>
    `).join('');
    
    document.getElementById('adminUserCount').textContent = toPersianNum(users.length);
}

function showAddUserModal() { 
    document.getElementById('newUserAccess').value = 'viewer';
    document.getElementById('limitedAccessOptions').style.display = 'none';
    openModal('addUserModal');
}

// Toggle limited access options
document.addEventListener('change', function(e) {
    if (e.target.id === 'newUserAccess') {
        document.getElementById('limitedAccessOptions').style.display = e.target.value === 'limited' ? 'block' : 'none';
    }
});

function saveNewUser() {
    const users = DB.get('users') || [];
    const name = document.getElementById('newUserName').value;
    const phone = document.getElementById('newUserPhone').value;
    
    if (!name || !phone) {
        showToast('نام و شماره موبایل الزامی است', 'error');
        return;
    }
    
    if (!/^09[0-9]{9}$/.test(phone)) {
        showToast('شماره موبایل معتبر وارد کنید', 'error');
        return;
    }
    
    const access = document.getElementById('newUserAccess').value;
    let limitedAccess = [];
    if (access === 'limited') {
        document.querySelectorAll('#limitedAccessOptions input[type="checkbox"]:checked').forEach(cb => {
            limitedAccess.push(cb.value);
        });
    }
    
    const newUser = {
        id: 'U' + Date.now(),
        name,
        phone,
        title: document.getElementById('newUserTitle').value || 'کاربر',
        access,
        email: document.getElementById('newUserEmail').value || '',
        status: 'active',
        online: false,
        limitedAccess
    };
    
    users.push(newUser);
    DB.set('users', users);
    closeModal('addUserModal');
    loadUsers();
    loadChatUserList();
    showToast(`کاربر ${name} با موفقیت تعریف شد`, 'success');
}

function editUserAccess(id) {
    const users = DB.get('users') || [];
    const user = users.find(u => u.id === id);
    if (!user) return;
    
    const levels = ['admin', 'editor', 'viewer', 'limited'];
    const labels = { admin: 'مدیر سیستم', editor: 'ویرایشگر', viewer: 'مشاهده‌گر', limited: 'محدود' };
    const currentIdx = levels.indexOf(user.access);
    const nextIdx = (currentIdx + 1) % levels.length;
    user.access = levels[nextIdx];
    
    DB.set('users', users);
    loadUsers();
    showToast(`سطح دسترسی ${user.name} به «${labels[user.access]}» تغییر کرد`, 'info');
}

function deleteUser(id) {
    let users = DB.get('users') || [];
    const user = users.find(u => u.id === id);
    if (!user) return;
    
    if (confirm(`آیا از حذف کاربر ${user.name} اطمینان دارید؟`)) {
        users = users.filter(u => u.id !== id);
        DB.set('users', users);
        loadUsers();
        showToast(`کاربر ${user.name} حذف شد`, 'warning');
    }
}

// ---- Chat ----
function loadChat() {
    loadChatUserList();
    loadChatMessages();
}

function loadChatUserList() {
    const users = DB.get('users') || [];
    const select = document.getElementById('chatWith');
    const otherUsers = users.filter(u => u.id !== (currentUser ? currentUser.id : 'U001'));
    
    select.innerHTML = otherUsers.map(u => 
        `<option value="${u.id}">${u.name} ${u.online ? '🟢' : '⚪'} (${u.title})</option>`
    ).join('');
}

function loadChatMessages() {
    const chats = DB.get('chats') || [];
    const selectedUser = document.getElementById('chatWith')?.value;
    const myId = currentUser ? currentUser.id : 'U001';
    
    const filtered = selectedUser 
        ? chats.filter(c => (c.from === myId && c.to === selectedUser) || (c.from === selectedUser && c.to === myId))
        : chats;
    
    const container = document.getElementById('chatMessages');
    container.innerHTML = filtered.map(m => {
        const isSent = m.from === myId;
        return `<div class="chat-bubble ${isSent ? 'sent' : 'received'}">
            ${m.text}
            <div class="time">${m.time}</div>
        </div>`;
    }).join('');
    
    container.scrollTop = container.scrollHeight;
}

function switchChatUser() {
    loadChatMessages();
}

function sendChat() {
    const input = document.getElementById('chatInput');
    const text = input.value.trim();
    if (!text) return;
    
    const chats = DB.get('chats') || [];
    const now = new Date();
    const time = pad(now.getHours()) + ':' + pad(now.getMinutes());
    
    chats.push({
        from: currentUser ? currentUser.id : 'U001',
        to: document.getElementById('chatWith').value,
        text,
        time: toPersianNum(time)
    });
    
    DB.set('chats', chats);
    input.value = '';
    loadChatMessages();
}

// ---- Reports ----
function generateReport() {
    const type = document.getElementById('reportType').value;
    const period = document.getElementById('reportPeriod').value;
    const container = document.getElementById('reportResult');
    
    let html = '';
    
    if (type === 'letters') {
        const letters = DB.get('letters') || [];
        const incoming = letters.filter(l => l.type === 'incoming').length;
        const outgoing = letters.filter(l => l.type === 'outgoing').length;
        const internal = letters.filter(l => l.type === 'internal').length;
        const approved = letters.filter(l => l.status === 'approved').length;
        const pending = letters.filter(l => l.status === 'pending').length;
        const archived = letters.filter(l => l.status === 'archived').length;
        
        html = `
            <div class="card">
                <div class="card-header"><h3><i class="fas fa-chart-bar"></i> گزارش مکاتبات</h3></div>
                <div class="card-body">
                    <div class="stats-grid" style="grid-template-columns:repeat(3, 1fr);">
                        <div class="stat-card"><div class="stat-icon blue"><i class="fas fa-inbox"></i></div><div class="stat-info"><h3>${toPersianNum(incoming)}</h3><p>وارده</p></div></div>
                        <div class="stat-card"><div class="stat-icon orange"><i class="fas fa-paper-plane"></i></div><div class="stat-info"><h3>${toPersianNum(outgoing)}</h3><p>صادره</p></div></div>
                        <div class="stat-card"><div class="stat-icon green"><i class="fas fa-building"></i></div><div class="stat-info"><h3>${toPersianNum(internal)}</h3><p>داخلی</p></div></div>
                    </div>
                    <table class="data-table" style="margin-top:16px;">
                        <tr><td>تأیید شده</td><td>${toPersianNum(approved)}</td></tr>
                        <tr><td>در انتظار</td><td>${toPersianNum(pending)}</td></tr>
                        <tr><td>بایگانی شده</td><td>${toPersianNum(archived)}</td></tr>
                        <tr><td>مجموع</td><td><strong>${toPersianNum(letters.length)}</strong></td></tr>
                    </table>
                </div>
            </div>`;
    } else if (type === 'users') {
        const users = DB.get('users') || [];
        const online = users.filter(u => u.online).length;
        html = `
            <div class="card">
                <div class="card-header"><h3><i class="fas fa-users"></i> گزارش کاربران</h3></div>
                <div class="card-body">
                    <table class="data-table">
                        <tr><td>کل کاربران</td><td>${toPersianNum(users.length)}</td></tr>
                        <tr><td>آنلاین</td><td>${toPersianNum(online)}</td></tr>
                        <tr><td>آفلاین</td><td>${toPersianNum(users.length - online)}</td></tr>
                        <tr><td>مدیران</td><td>${toPersianNum(users.filter(u => u.access === 'admin').length)}</td></tr>
                        <tr><td>ویرایشگران</td><td>${toPersianNum(users.filter(u => u.access === 'editor').length)}</td></tr>
                        <tr><td>مشاهده‌گران</td><td>${toPersianNum(users.filter(u => u.access === 'viewer').length)}</td></tr>
                    </table>
                </div>
            </div>`;
    } else if (type === 'archive') {
        const archive = DB.get('archive') || [];
        html = `
            <div class="card">
                <div class="card-header"><h3><i class="fas fa-archive"></i> گزارش بایگانی</h3></div>
                <div class="card-body">
                    <p>تعداد کل اسناد بایگانی: <strong>${toPersianNum(archive.length)}</strong></p>
                    <table class="data-table" style="margin-top:12px;">
                        ${archive.map(a => '<tr><td>' + a.title + '</td><td>' + a.date + '</td></tr>').join('')}
                    </table>
                </div>
            </div>`;
    } else {
        html = `
            <div class="card">
                <div class="card-header"><h3><i class="fas fa-chart-line"></i> گزارش فعالیت</h3></div>
                <div class="card-body">
                    <p>گزارش فعالیت کاربران در بازه انتخاب شده</p>
                    <div class="progress-bar" style="margin-top:12px;"><div class="fill" style="width:75%; background:var(--success);"></div></div>
                    <p style="margin-top:4px; font-size:12px; color:var(--text-light);">۷۵٪ فعالیت هدف انجام شده</p>
                </div>
            </div>`;
    }
    
    container.innerHTML = html;
    showToast('گزارش با موفقیت تولید شد', 'success');
}

function exportReportPDF() {
    const content = document.getElementById('reportResult').innerHTML;
    if (!content) {
        showToast('ابتدا گزارش را تولید کنید', 'warning');
        return;
    }
    const win = window.open('', '_blank');
    win.document.write(`<html dir="rtl" lang="fa"><head><title>گزارش</title><style>body{font-family:Tahoma,sans-serif;padding:20px;}table{width:100%;border-collapse:collapse;margin:16px 0;}td,th{padding:8px;border:1px solid #ddd;text-align:right;}h3{color:#1a237e;}</style></head><body>${content}</body></html>`);
    win.document.close();
    setTimeout(() => win.print(), 500);
}

function exportReportExcel() {
    const letters = DB.get('letters') || [];
    let csv = '\uFEFF' + 'شماره,موضوع,نوع,فرستنده,گیرنده,تاریخ,وضعیت\n';
    letters.forEach(l => {
        csv += `${l.number},${l.subject},${l.type},${l.from},${l.to},${l.date},${l.status}\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'report.csv';
    link.click();
    showToast('فایل اکسل دانلود شد', 'success');
}

function emailReport() {
    const email = currentUser?.email || prompt('ایمیل خود را وارد کنید:');
    if (email) {
        showToast(`گزارش به ${email} ارسال شد`, 'success');
    }
}

function exportLetters() {
    const letters = DB.get('letters') || [];
    let csv = '\uFEFF' + 'شماره,موضوع,نوع,فرستنده,گیرنده,تاریخ,وضعیت\n';
    letters.forEach(l => {
        csv += `${l.number},${l.subject},${l.type},${l.from},${l.to},${l.date},${l.status}\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'letters.csv';
    link.click();
    showToast('خروجی نامه‌ها دریافت شد', 'success');
}

// ---- Backup ----
function loadBackups() {
    const backups = DB.get('backups') || [];
    const tbody = document.getElementById('backupHistoryBody');
    tbody.innerHTML = backups.map(b => `
        <tr>
            <td>${b.date}</td>
            <td>${b.time}</td>
            <td>${toPersianNum(b.size)} مگابایت</td>
            <td>${b.type}</td>
            <td>
                <button class="btn btn-sm btn-outline" onclick="downloadBackup('${b.id}')" style="width:auto; padding:4px 8px;"><i class="fas fa-download"></i></button>
            </td>
        </tr>
    `).join('');
    
    document.getElementById('backupCount').textContent = toPersianNum(backups.length);
}

function createBackup() {
    const allData = {
        letters: DB.get('letters'),
        users: DB.get('users'),
        chats: DB.get('chats'),
        archive: DB.get('archive'),
        folders: DB.get('folders'),
        notifications: DB.get('notifications'),
        settings: DB.get('settings'),
        backupDate: getTodayJalali(),
        version: '1.0.0'
    };
    
    const json = JSON.stringify(allData, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `backup_${getTodayJalali().replace(/\//g, '-')}.json`;
    link.click();
    
    // Save backup record
    const backups = DB.get('backups') || [];
    const now = new Date();
    backups.push({
        id: 'B' + Date.now(),
        date: getTodayJalali(),
        time: toPersianNum(pad(now.getHours()) + ':' + pad(now.getMinutes())),
        size: (json.length / 1024 / 1024).toFixed(1),
        type: 'دستی'
    });
    DB.set('backups', backups);
    loadBackups();
    
    showToast('پشتیبان با موفقیت در حافظه گوشی ذخیره شد', 'success');
}

function emailBackup() {
    const email = currentUser?.email || prompt('ایمیل مقصد را وارد کنید:');
    if (email) {
        const allData = { letters: DB.get('letters'), users: DB.get('users'), chats: DB.get('chats'), archive: DB.get('archive'), settings: DB.get('settings') };
        showToast(`پشتیبان به ${email} ارسال شد`, 'success');
    }
}

function restoreBackup() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
        const file = e.target.files[0];
        const reader = new FileReader();
        reader.onload = (ev) => {
            try {
                const data = JSON.parse(ev.target.result);
                if (data.letters) DB.set('letters', data.letters);
                if (data.users) DB.set('users', data.users);
                if (data.chats) DB.set('chats', data.chats);
                if (data.archive) DB.set('archive', data.archive);
                if (data.folders) DB.set('folders', data.folders);
                if (data.settings) DB.set('settings', data.settings);
                
                showToast('بازیابی با موفقیت انجام شد. لطفاً برنامه را بازنشانی کنید.', 'success');
                setTimeout(() => location.reload(), 2000);
            } catch (err) {
                showToast('فایل پشتیبان نامعتبر است', 'error');
            }
        };
        reader.readAsText(file);
    };
    input.click();
}

function downloadBackup(id) {
    createBackup(); // Re-create current backup as download
}

// ---- Settings ----
function applySettings() {
    const settings = DB.get('settings');
    if (!settings) return;
    
    // Theme
    document.documentElement.style.setProperty('--primary', settings.theme.primary);
    document.documentElement.style.setProperty('--primary-light', settings.theme.primary + 'aa');
    
    // Font
    document.documentElement.style.setProperty('--font-family', settings.font.family);
    document.documentElement.style.setProperty('--font-size', settings.font.size + 'px');
    document.body.style.fontFamily = settings.font.family;
    document.body.style.fontSize = settings.font.size + 'px';
    
    // Fill settings form
    if (settings.company) {
        document.getElementById('settingCompanyName').value = settings.company.name || '';
        document.getElementById('settingCompanySub').value = settings.company.sub || '';
        document.getElementById('settingCompanyAddr').value = settings.company.address || '';
        document.getElementById('settingCompanyPhone').value = settings.company.phone || '';
    }
    document.getElementById('fontSizeSlider').value = settings.font.size;
    document.getElementById('fontSizeValue').textContent = settings.font.size + 'px';
    document.getElementById('fontFamily').value = settings.font.family;
}

function setThemeColor(color, el) {
    document.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active'));
    el.classList.add('active');
    
    document.documentElement.style.setProperty('--primary', color);
    document.documentElement.style.setProperty('--primary-light', color + 'aa');
    document.documentElement.style.setProperty('--primary-dark', color + '80');
    
    const settings = DB.get('settings');
    settings.theme.primary = color;
    DB.set('settings', settings);
    showToast('رنگ پوسته تغییر کرد', 'success');
}

function setMode(mode) {
    const settings = DB.get('settings');
    settings.theme.mode = mode;
    
    if (mode === 'dark') {
        document.documentElement.style.setProperty('--bg', '#121212');
        document.documentElement.style.setProperty('--card', '#1e1e1e');
        document.documentElement.style.setProperty('--text', '#e0e0e0');
        document.documentElement.style.setProperty('--text-light', '#9e9e9e');
        document.documentElement.style.setProperty('--border', '#333333');
    } else {
        document.documentElement.style.setProperty('--bg', '#f5f5f5');
        document.documentElement.style.setProperty('--card', '#ffffff');
        document.documentElement.style.setProperty('--text', '#212121');
        document.documentElement.style.setProperty('--text-light', '#757575');
        document.documentElement.style.setProperty('--border', '#e0e0e0');
    }
    
    DB.set('settings', settings);
    showToast(`حالت ${mode === 'dark' ? 'تیره' : 'روشن'} فعال شد`, 'success');
}

function changeFont(font) {
    const settings = DB.get('settings');
    settings.font.family = font;
    DB.set('settings', settings);
    applySettings();
    showToast('فونت برنامه تغییر کرد', 'success');
}

function changeFontSize(size) {
    document.getElementById('fontSizeValue').textContent = size + 'px';
    const settings = DB.get('settings');
    settings.font.size = parseInt(size);
    DB.set('settings', settings);
    applySettings();
}

function changeIconStyle(style) {
    const settings = DB.get('settings');
    settings.icons = style;
    DB.set('settings', settings);
    showToast('سبک آیکون‌ها تغییر کرد', 'success');
}

function updateCompanySettings() {
    const settings = DB.get('settings');
    settings.company = {
        name: document.getElementById('settingCompanyName').value,
        sub: document.getElementById('settingCompanySub').value,
        address: document.getElementById('settingCompanyAddr').value,
        phone: document.getElementById('settingCompanyPhone').value
    };
    DB.set('settings', settings);
    
    // Update stamp
    document.getElementById('stampCompanyName').textContent = settings.company.name;
}

function updateCompanyLogo() {
    showToast('لوگوی شرکت به‌روزرسانی شد', 'success');
}

// ---- Signature Canvas ----
function initSignatureCanvas() {
    const canvas = document.getElementById('sigCanvas');
    if (!canvas) return;
    sigCtx = canvas.getContext('2d');
    sigCtx.strokeStyle = '#1a237e';
    sigCtx.lineWidth = 2;
    sigCtx.lineCap = 'round';
    
    canvas.addEventListener('mousedown', (e) => {
        sigDrawing = true;
        sigCtx.beginPath();
        sigCtx.moveTo(e.offsetX, e.offsetY);
    });
    
    canvas.addEventListener('mousemove', (e) => {
        if (!sigDrawing) return;
        sigCtx.lineTo(e.offsetX, e.offsetY);
        sigCtx.stroke();
    });
    
    canvas.addEventListener('mouseup', () => { sigDrawing = false; });
    canvas.addEventListener('mouseleave', () => { sigDrawing = false; });
    
    // Touch support
    canvas.addEventListener('touchstart', (e) => {
        e.preventDefault();
        sigDrawing = true;
        const rect = canvas.getBoundingClientRect();
        const touch = e.touches[0];
        sigCtx.beginPath();
        sigCtx.moveTo(touch.clientX - rect.left, touch.clientY - rect.top);
    });
    
    canvas.addEventListener('touchmove', (e) => {
        e.preventDefault();
        if (!sigDrawing) return;
        const rect = canvas.getBoundingClientRect();
        const touch = e.touches[0];
        sigCtx.lineTo(touch.clientX - rect.left, touch.clientY - rect.top);
        sigCtx.stroke();
    });
    
    canvas.addEventListener('touchend', () => { sigDrawing = false; });
}

function clearSignature(canvasId) {
    const canvas = document.getElementById(canvasId);
    if (canvas && sigCtx) {
        sigCtx.clearRect(0, 0, canvas.width, canvas.height);
    }
}

// ---- Notifications ----
function showNotifications() {
    const notifs = DB.get('notifications') || [];
    const container = document.getElementById('notificationList');
    
    container.innerHTML = notifs.map(n => `
        <div style="display:flex; align-items:center; gap:12px; padding:12px; border-bottom:1px solid var(--border); ${!n.read ? 'background:rgba(26,35,126,0.03);' : ''}">
            <i class="fas ${n.icon}" style="color:var(--primary); width:24px; text-align:center;"></i>
            <div style="flex:1;">
                <div style="font-size:13px;">${n.text}</div>
                <div style="font-size:11px; color:var(--text-light);">${n.time}</div>
            </div>
        </div>
    `).join('');
    
    if (notifs.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="fas fa-bell-slash"></i><p>اعلانی وجود ندارد</p></div>';
    }
    
    openModal('notificationModal');
}

function showUserMenu() {
    if (confirm('آیا می‌خواهید از حساب کاربری خارج شوید؟')) {
        logout();
    }
}

// ---- Utilities ----
function statusText(s) {
    const map = { pending: 'در انتظار', approved: 'تأیید شده', rejected: 'رد شده', draft: 'پیش‌نویس', archived: 'بایگانی', sent: 'ارسال شده' };
    return map[s] || s;
}

function toPersianNum(num) {
    if (typeof num === 'string') {
        return num.replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
    }
    return String(num).replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
}

function openModal(id) {
    document.getElementById(id).classList.add('show');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('show');
}

function showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    const icons = { success: 'fa-check-circle', error: 'fa-times-circle', warning: 'fa-exclamation-triangle', info: 'fa-info-circle' };
    toast.className = `toast ${type}`;
    toast.innerHTML = `<i class="fas ${icons[type]}"></i> ${message}`;
    toast.classList.add('show');
    
    setTimeout(() => toast.classList.remove('show'), 3000);
}

function clearAllData() {
    if (confirm('آیا از پاک‌سازی تمام داده‌ها اطمینان دارید؟ این عمل غیرقابل بازگشت است.')) {
        const keys = Object.keys(localStorage).filter(k => k.startsWith('oa_'));
        keys.forEach(k => localStorage.removeItem(k));
        initData();
        loadDashboard();
        loadLetters();
        loadUsers();
        loadArchive();
        loadFolders();
        showToast('تمام داده‌ها پاک‌سازی شد', 'warning');
    }
}

// ---- Responsive ----
window.addEventListener('resize', () => {
    if (window.innerWidth <= 768) {
        document.getElementById('sidebar').classList.remove('collapsed');
        document.getElementById('header').classList.remove('sidebar-collapsed');
        document.getElementById('mainContent').classList.remove('full');
    }
});